#!/usr/bin/env bash
# Exp-9 Part 1: Two EC2 web servers behind an Application Load Balancer
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
SUFFIX="$(date +%s | tail -c 6)"
PROJECT_TAG="exp9"

WEB_SG_NAME="web-sg-${SUFFIX}"
ALB_SG_NAME="alb-sg-${SUFFIX}"
ALB_NAME="web-alb-${SUFFIX}"
TG_NAME="web-tg-${SUFFIX}"
INSTANCE1_NAME="WebServer-1-${SUFFIX}"
INSTANCE2_NAME="WebServer-2-${SUFFIX}"

echo ">> Region : $REGION"
echo ">> Suffix : $SUFFIX"

# --- discover default VPC + 2 subnets in different AZs ---
VPC_ID=$(aws ec2 describe-vpcs --region "$REGION" \
  --filters Name=is-default,Values=true \
  --query 'Vpcs[0].VpcId' --output text)
SUBNETS=$(aws ec2 describe-subnets --region "$REGION" \
  --filters Name=vpc-id,Values="$VPC_ID" Name=default-for-az,Values=true \
  --query 'Subnets[*].[SubnetId,AvailabilityZone]' --output text)
SUBNET1=$(echo "$SUBNETS" | awk 'NR==1{print $1}')
SUBNET2=$(echo "$SUBNETS" | awk 'NR==2{print $1}')
ALB_SUBNETS=$(echo "$SUBNETS" | awk '{print $1}' | tr '\n' ' ')
echo ">> VPC    : $VPC_ID"
echo ">> Subnets: $ALB_SUBNETS"

# --- latest Amazon Linux 2023 AMI via SSM parameter ---
AMI_ID=$(aws ssm get-parameter --region "$REGION" \
  --name /aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64 \
  --query 'Parameter.Value' --output text)
echo ">> AMI    : $AMI_ID"

# --- security group for EC2 (port 80 + 22 from anywhere) ---
WEB_SG=$(aws ec2 create-security-group --region "$REGION" \
  --group-name "$WEB_SG_NAME" --vpc-id "$VPC_ID" \
  --description "exp9 web servers" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --region "$REGION" \
  --group-id "$WEB_SG" --protocol tcp --port 80 --cidr 0.0.0.0/0 >/dev/null
aws ec2 authorize-security-group-ingress --region "$REGION" \
  --group-id "$WEB_SG" --protocol tcp --port 22 --cidr 0.0.0.0/0 >/dev/null
aws ec2 create-tags --region "$REGION" --resources "$WEB_SG" \
  --tags Key=Project,Value="$PROJECT_TAG" Key=Name,Value="$WEB_SG_NAME"
echo ">> Web SG : $WEB_SG"

# --- security group for ALB (port 80 anywhere) ---
ALB_SG=$(aws ec2 create-security-group --region "$REGION" \
  --group-name "$ALB_SG_NAME" --vpc-id "$VPC_ID" \
  --description "exp9 ALB" --query 'GroupId' --output text)
aws ec2 authorize-security-group-ingress --region "$REGION" \
  --group-id "$ALB_SG" --protocol tcp --port 80 --cidr 0.0.0.0/0 >/dev/null
aws ec2 authorize-security-group-ingress --region "$REGION" \
  --group-id "$ALB_SG" --protocol tcp --port 443 --cidr 0.0.0.0/0 >/dev/null
aws ec2 create-tags --region "$REGION" --resources "$ALB_SG" \
  --tags Key=Project,Value="$PROJECT_TAG" Key=Name,Value="$ALB_SG_NAME"
echo ">> ALB SG : $ALB_SG"

# --- launch 2 EC2 instances with user-data ---
USERDATA1=$(cat <<EOF
#!/bin/bash
yum update -y
yum install -y httpd
systemctl start httpd
systemctl enable httpd
echo "This is Server 1" > /var/www/html/index.html
EOF
)
USERDATA2=$(cat <<EOF
#!/bin/bash
yum update -y
yum install -y httpd
systemctl start httpd
systemctl enable httpd
echo "This is Server 2" > /var/www/html/index.html
EOF
)

I1=$(aws ec2 run-instances --region "$REGION" \
  --image-id "$AMI_ID" --instance-type t3.micro \
  --subnet-id "$SUBNET1" --security-group-ids "$WEB_SG" \
  --user-data "$USERDATA1" \
  --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=$INSTANCE1_NAME},{Key=Project,Value=$PROJECT_TAG}]" \
  --query 'Instances[0].InstanceId' --output text)
I2=$(aws ec2 run-instances --region "$REGION" \
  --image-id "$AMI_ID" --instance-type t3.micro \
  --subnet-id "$SUBNET2" --security-group-ids "$WEB_SG" \
  --user-data "$USERDATA2" \
  --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=$INSTANCE2_NAME},{Key=Project,Value=$PROJECT_TAG}]" \
  --query 'Instances[0].InstanceId' --output text)
echo ">> Instances: $I1 $I2"
echo ">> Waiting for instances to be running..."
aws ec2 wait instance-running --region "$REGION" --instance-ids "$I1" "$I2"
echo ">> Instances running"

# --- target group ---
TG_ARN=$(aws elbv2 create-target-group --region "$REGION" \
  --name "$TG_NAME" --protocol HTTP --port 80 \
  --vpc-id "$VPC_ID" --target-type instance \
  --health-check-protocol HTTP --health-check-path / \
  --query 'TargetGroups[0].TargetGroupArn' --output text)
aws elbv2 add-tags --region "$REGION" --resource-arns "$TG_ARN" \
  --tags Key=Project,Value="$PROJECT_TAG"
echo ">> Target group: $TG_ARN"

# --- register instances ---
aws elbv2 register-targets --region "$REGION" --target-group-arn "$TG_ARN" \
  --targets Id="$I1" Id="$I2" >/dev/null
echo ">> Targets registered"

# --- ALB ---
ALB_ARN=$(aws elbv2 create-load-balancer --region "$REGION" \
  --name "$ALB_NAME" --type application --scheme internet-facing \
  --subnets $ALB_SUBNETS --security-groups "$ALB_SG" \
  --tags Key=Project,Value="$PROJECT_TAG" \
  --query 'LoadBalancers[0].LoadBalancerArn' --output text)
echo ">> ALB: $ALB_ARN"

# --- listener: forward to TG ---
aws elbv2 create-listener --region "$REGION" \
  --load-balancer-arn "$ALB_ARN" --protocol HTTP --port 80 \
  --default-actions "Type=forward,TargetGroupArn=$TG_ARN" >/dev/null
echo ">> Listener wired"

echo ">> Waiting for ALB to become active..."
aws elbv2 wait load-balancer-available --region "$REGION" --load-balancer-arns "$ALB_ARN"

DNS=$(aws elbv2 describe-load-balancers --region "$REGION" \
  --load-balancer-arns "$ALB_ARN" --query 'LoadBalancers[0].DNSName' --output text)

# --- save state for part 2 ---
cat > /tmp/exp9-state.sh <<EOF
SUFFIX=$SUFFIX
VPC_ID=$VPC_ID
ALB_SUBNETS="$ALB_SUBNETS"
WEB_SG=$WEB_SG
ALB_SG=$ALB_SG
TG_ARN=$TG_ARN
ALB_ARN=$ALB_ARN
INSTANCE1=$I1
INSTANCE2=$I2
DNS=$DNS
EOF

cat <<EOF

------------------------------------------------------------
ALB DNS : http://$DNS
Targets : $I1, $I2
TG ARN  : $TG_ARN

httpd is being installed via user-data — give it ~60-90s, then refresh
the URL in a browser. Each refresh should alternate "Server 1" / "Server 2".

State saved to /tmp/exp9-state.sh for Part 2.
------------------------------------------------------------
EOF
