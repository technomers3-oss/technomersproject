#!/usr/bin/env bash
# Exp-10: Elastic Beanstalk Tomcat web app, ALB, t3.micro
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
SUFFIX="$(date +%s | tail -c 6)"
PROJECT_TAG="exp10"

APP_NAME="TomcatDemoApp-${SUFFIX}"
ENV_NAME="TomcatDemoEnv-${SUFFIX}"
BUCKET="eb-tomcat-source-${SUFFIX}"
SERVICE_ROLE="EBServiceRole-${SUFFIX}"
INSTANCE_ROLE="EBInstanceRole-${SUFFIX}"
INSTANCE_PROFILE="EBInstanceProfile-${SUFFIX}"

echo ">> App  : $APP_NAME"
echo ">> Env  : $ENV_NAME"

# 1. EB service role
SVC_TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"elasticbeanstalk.amazonaws.com"},"Action":"sts:AssumeRole","Condition":{"StringEquals":{"sts:ExternalId":"elasticbeanstalk"}}}]}'
SVC_ROLE_ARN=$(aws iam create-role --role-name "$SERVICE_ROLE" \
  --assume-role-policy-document "$SVC_TRUST" --query 'Role.Arn' --output text)
aws iam attach-role-policy --role-name "$SERVICE_ROLE" \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSElasticBeanstalkEnhancedHealth >/dev/null
aws iam attach-role-policy --role-name "$SERVICE_ROLE" \
  --policy-arn arn:aws:iam::aws:policy/AWSElasticBeanstalkManagedUpdatesCustomerRolePolicy >/dev/null

# 2. EC2 instance profile
EC2_TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ec2.amazonaws.com"},"Action":"sts:AssumeRole"}]}'
aws iam create-role --role-name "$INSTANCE_ROLE" \
  --assume-role-policy-document "$EC2_TRUST" >/dev/null
aws iam attach-role-policy --role-name "$INSTANCE_ROLE" \
  --policy-arn arn:aws:iam::aws:policy/AWSElasticBeanstalkWebTier >/dev/null
aws iam attach-role-policy --role-name "$INSTANCE_ROLE" \
  --policy-arn arn:aws:iam::aws:policy/AWSElasticBeanstalkWorkerTier >/dev/null
aws iam create-instance-profile --instance-profile-name "$INSTANCE_PROFILE" >/dev/null
aws iam add-role-to-instance-profile --instance-profile-name "$INSTANCE_PROFILE" \
  --role-name "$INSTANCE_ROLE"

echo ">> Roles created, waiting 15s for IAM propagation..."
sleep 15

# 3. Source S3 bucket + sample WAR
if [ "$REGION" = "us-east-1" ]; then
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" >/dev/null
else
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
    --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
fi

WORK="$(mktemp -d)"
WAR="$WORK/sample.war"
echo ">> Downloading sample WAR..."
if ! curl -fsSL -o "$WAR" "https://tomcat.apache.org/tomcat-6.0-doc/appdev/sample/sample.war"; then
  echo ">> Tomcat sample unavailable, building minimal WAR..."
  mkdir -p "$WORK/src/WEB-INF"
  cat > "$WORK/src/index.jsp" <<'JSP'
<html><body>
<h1>Hello from Elastic Beanstalk Tomcat!</h1>
<p>Version: 1</p>
<p>Time: <%= new java.util.Date() %></p>
</body></html>
JSP
  cat > "$WORK/src/WEB-INF/web.xml" <<'XML'
<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee" version="5.0"/>
XML
  (cd "$WORK/src" && jar -cf "$WAR" . 2>/dev/null || zip -qr "$WAR" .)
fi

aws s3 cp "$WAR" "s3://$BUCKET/sample-v1.war" >/dev/null
echo ">> WAR uploaded to s3://$BUCKET/sample-v1.war"

# 4. EB application + version
aws elasticbeanstalk create-application --region "$REGION" \
  --application-name "$APP_NAME" \
  --description "exp10 Tomcat demo" >/dev/null
aws elasticbeanstalk create-application-version --region "$REGION" \
  --application-name "$APP_NAME" \
  --version-label v1 \
  --source-bundle S3Bucket="$BUCKET",S3Key=sample-v1.war \
  --auto-create-application >/dev/null
echo ">> EB application + version v1 created"

# 5. Find latest Tomcat solution stack
STACK=$(aws elasticbeanstalk list-available-solution-stacks --region "$REGION" \
  --query 'SolutionStacks[?contains(@,`Tomcat`) && contains(@,`Corretto`)] | [0]' --output text)
echo ">> Solution stack: $STACK"

# 6. Discover default VPC + subnets in AZs that support t3.micro
VPC_ID=$(aws ec2 describe-vpcs --region "$REGION" \
  --filters Name=is-default,Values=true --query 'Vpcs[0].VpcId' --output text)
GOOD_AZS=$(aws ec2 describe-instance-type-offerings --region "$REGION" \
  --location-type availability-zone \
  --filters Name=instance-type,Values=t3.micro \
  --query 'InstanceTypeOfferings[].Location' --output text | tr '\t' ',')
SUBNET_LIST=$(aws ec2 describe-subnets --region "$REGION" \
  --filters Name=vpc-id,Values="$VPC_ID" Name=default-for-az,Values=true \
    "Name=availability-zone,Values=$GOOD_AZS" \
  --query 'Subnets[].SubnetId' --output text | tr '\t' ',')

# 7. Environment options
OPTIONS=$(jq -n \
  --arg ip "$INSTANCE_PROFILE" --arg sr "$SVC_ROLE_ARN" \
  --arg vpc "$VPC_ID" --arg subs "$SUBNET_LIST" '[
    {Namespace:"aws:autoscaling:launchconfiguration",OptionName:"IamInstanceProfile",Value:$ip},
    {Namespace:"aws:autoscaling:launchconfiguration",OptionName:"InstanceType",Value:"t3.micro"},
    {Namespace:"aws:elasticbeanstalk:environment",OptionName:"ServiceRole",Value:$sr},
    {Namespace:"aws:elasticbeanstalk:environment",OptionName:"EnvironmentType",Value:"LoadBalanced"},
    {Namespace:"aws:elasticbeanstalk:environment",OptionName:"LoadBalancerType",Value:"application"},
    {Namespace:"aws:autoscaling:asg",OptionName:"MinSize",Value:"1"},
    {Namespace:"aws:autoscaling:asg",OptionName:"MaxSize",Value:"2"},
    {Namespace:"aws:ec2:vpc",OptionName:"VPCId",Value:$vpc},
    {Namespace:"aws:ec2:vpc",OptionName:"Subnets",Value:$subs},
    {Namespace:"aws:ec2:vpc",OptionName:"ELBSubnets",Value:$subs},
    {Namespace:"aws:ec2:vpc",OptionName:"AssociatePublicIpAddress",Value:"true"}
  ]')

# 8. Create environment
aws elasticbeanstalk create-environment --region "$REGION" \
  --application-name "$APP_NAME" \
  --environment-name "$ENV_NAME" \
  --version-label v1 \
  --solution-stack-name "$STACK" \
  --option-settings "$OPTIONS" >/dev/null

echo ">> Environment creating... (this takes 4-7 minutes)"
echo ">> Polling status..."
while :; do
  ST=$(aws elasticbeanstalk describe-environments --region "$REGION" \
    --environment-names "$ENV_NAME" --query 'Environments[0].Status' --output text)
  echo "   status=$ST"
  case "$ST" in
    Ready)  break ;;
    Terminated|*Fail*) echo ">> environment failed"; exit 1 ;;
    *) sleep 20 ;;
  esac
done

URL=$(aws elasticbeanstalk describe-environments --region "$REGION" \
  --environment-names "$ENV_NAME" --query 'Environments[0].CNAME' --output text)
HEALTH=$(aws elasticbeanstalk describe-environments --region "$REGION" \
  --environment-names "$ENV_NAME" --query 'Environments[0].Health' --output text)

cat > /tmp/exp10-state.sh <<EOF
APP_NAME=$APP_NAME
ENV_NAME=$ENV_NAME
BUCKET=$BUCKET
SERVICE_ROLE=$SERVICE_ROLE
INSTANCE_ROLE=$INSTANCE_ROLE
INSTANCE_PROFILE=$INSTANCE_PROFILE
URL=$URL
EOF

cat <<EOF

------------------------------------------------------------
URL    : http://$URL
Status : Ready  (Health: $HEALTH)
App    : $APP_NAME
Env    : $ENV_NAME

To deploy a new version (v2):
  # edit/repackage your WAR locally as new.war
  aws s3 cp new.war s3://$BUCKET/sample-v2.war
  aws elasticbeanstalk create-application-version --region $REGION \\
    --application-name $APP_NAME --version-label v2 \\
    --source-bundle S3Bucket=$BUCKET,S3Key=sample-v2.war
  aws elasticbeanstalk update-environment --region $REGION \\
    --environment-name $ENV_NAME --version-label v2

State saved to /tmp/exp10-state.sh
------------------------------------------------------------
EOF
