#!/usr/bin/env bash
# Exp-8 Part 1: SNS topic + email subscription + publish a test message
# Usage:  ./exp8-part1-sns-email.sh <email>
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
EMAIL_RE='^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
EMAIL="${1:-}"
if [[ -z "$EMAIL" ]]; then
  echo "ERROR: email argument is required." >&2
  echo "Usage: $0 <email>" >&2
fi
while [[ ! "$EMAIL" =~ $EMAIL_RE ]]; do
  [[ -n "$EMAIL" ]] && echo "ERROR: '$EMAIL' is not a valid email address." >&2
  read -r -p ">> Enter a valid email to proceed: " EMAIL
done
SUFFIX="$(date +%s | tail -c 6)"
TOPIC_NAME="DemoNotifications-${SUFFIX}"

echo ">> Region: $REGION"
echo ">> Email : $EMAIL"
echo ">> Topic : $TOPIC_NAME"

TOPIC_ARN=$(aws sns create-topic --region "$REGION" --name "$TOPIC_NAME" --query 'TopicArn' --output text)
echo ">> Topic ARN: $TOPIC_ARN"

aws sns subscribe --region "$REGION" \
  --topic-arn "$TOPIC_ARN" \
  --protocol email \
  --notification-endpoint "$EMAIL" >/dev/null
echo ">> Subscription created. CONFIRM the link in $EMAIL inbox (also check spam)."

read -r -p ">> Press ENTER after confirming the email subscription... "

aws sns publish --region "$REGION" \
  --topic-arn "$TOPIC_ARN" \
  --subject "Hello from SNS" \
  --message "This is a test message from $TOPIC_NAME." >/dev/null
echo ">> Published. Check $EMAIL inbox."

cat <<EOF

Cleanup:
  aws sns delete-topic --region $REGION --topic-arn $TOPIC_ARN
EOF
