#!/usr/bin/env bash
# Exp-7: S3 upload -> Lambda -> DynamoDB logger
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
SUFFIX="$(date +%s | tail -c 6)"

BUCKET="s3-to-dynamo-demo-${SUFFIX}"
TABLE="S3UploadLogs-${SUFFIX}"
FUNCTION="S3ToDynamoLogger-${SUFFIX}"
ROLE_NAME="S3ToDynamoLambdaRole-${SUFFIX}"

echo ">> Bucket   : $BUCKET"
echo ">> Table    : $TABLE"
echo ">> Function : $FUNCTION"
echo ">> Role     : $ROLE_NAME"

# 1. IAM role for Lambda
TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}'

ROLE_ARN=$(aws iam create-role --role-name "$ROLE_NAME" \
  --assume-role-policy-document "$TRUST" \
  --query 'Role.Arn' --output text)

aws iam attach-role-policy --role-name "$ROLE_NAME" \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole >/dev/null
aws iam attach-role-policy --role-name "$ROLE_NAME" \
  --policy-arn arn:aws:iam::aws:policy/AmazonDynamoDBFullAccess >/dev/null
aws iam attach-role-policy --role-name "$ROLE_NAME" \
  --policy-arn arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess >/dev/null

echo ">> Waiting for IAM role to propagate..."
sleep 12

# 2. S3 bucket
if [ "$REGION" = "us-east-1" ]; then
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" >/dev/null
else
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
    --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
fi
echo ">> S3 bucket created"

# 3. DynamoDB table (partition key: id)
aws dynamodb create-table --region "$REGION" \
  --table-name "$TABLE" \
  --attribute-definitions AttributeName=id,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST >/dev/null
aws dynamodb wait table-exists --region "$REGION" --table-name "$TABLE"
echo ">> DynamoDB table ACTIVE"

# 4. Lambda code
WORK="$(mktemp -d)"
cat > "$WORK/lambda_function.py" <<EOF
import boto3
from uuid import uuid4

def lambda_handler(event, context):
    s3 = boto3.client("s3")
    dynamodb = boto3.resource('dynamodb')

    if 'Records' in event:
        for record in event['Records']:
            bucket_name = record['s3']['bucket']['name']
            object_key  = record['s3']['object']['key']
            size        = record['s3']['object'].get('size', -1)
            event_name  = record.get('eventName', 'Unknown')
            event_time  = record.get('eventTime', 'Unknown')

            dynamoTable = dynamodb.Table('${TABLE}')
            dynamoTable.put_item(Item={
                'id'        : str(uuid4()),
                'Bucket'    : bucket_name,
                'Object'    : object_key,
                'Size'      : size,
                'Event'     : event_name,
                'EventTime' : event_time,
            })
    else:
        print("No 'Records' key found in the event.")
EOF
(cd "$WORK" && zip -q function.zip lambda_function.py)

# 5. Create Lambda (retry while role propagates)
for i in 1 2 3 4 5; do
  if aws lambda create-function --region "$REGION" \
      --function-name "$FUNCTION" \
      --runtime python3.12 \
      --role "$ROLE_ARN" \
      --handler lambda_function.lambda_handler \
      --zip-file "fileb://$WORK/function.zip" \
      --timeout 30 >/dev/null 2>&1; then
    echo ">> Lambda created (attempt $i)"
    break
  fi
  echo "   role not ready yet, retrying in 6s..."; sleep 6
done

aws lambda wait function-active-v2 --region "$REGION" --function-name "$FUNCTION"
echo ">> Lambda ACTIVE"

# 6. Allow S3 to invoke Lambda
aws lambda add-permission --region "$REGION" \
  --function-name "$FUNCTION" \
  --statement-id "s3invoke-${SUFFIX}" \
  --action "lambda:InvokeFunction" \
  --principal s3.amazonaws.com \
  --source-arn "arn:aws:s3:::$BUCKET" \
  --source-account "$ACCOUNT_ID" >/dev/null

# 7. Wire S3 -> Lambda
aws s3api put-bucket-notification-configuration --region "$REGION" \
  --bucket "$BUCKET" \
  --notification-configuration "{
    \"LambdaFunctionConfigurations\":[{
      \"LambdaFunctionArn\":\"arn:aws:lambda:${REGION}:${ACCOUNT_ID}:function:${FUNCTION}\",
      \"Events\":[\"s3:ObjectCreated:*\"]
    }]
  }"
echo ">> Trigger wired"

cat <<'EOF'

------------------------------------------------------------
Demo flow:
EOF
cat <<EOF
   echo "hello \$(date)" > demo.txt
   aws s3 cp demo.txt s3://${BUCKET}/
   aws dynamodb scan --table-name ${TABLE} --region ${REGION}
   aws logs tail /aws/lambda/${FUNCTION} --region ${REGION} --follow

Resources:
   Bucket   : ${BUCKET}
   Table    : ${TABLE}
   Function : ${FUNCTION}
   Role     : ${ROLE_NAME}
------------------------------------------------------------
EOF
