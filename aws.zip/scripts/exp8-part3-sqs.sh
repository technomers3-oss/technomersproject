#!/usr/bin/env bash
# Exp-8 Part 3: SQS basic send / receive / delete
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
SUFFIX="$(date +%s | tail -c 6)"
QUEUE_NAME="DemoQueue-${SUFFIX}"

echo ">> Queue: $QUEUE_NAME"

QUEUE_URL=$(aws sqs create-queue --region "$REGION" --queue-name "$QUEUE_NAME" --query 'QueueUrl' --output text)
echo ">> URL: $QUEUE_URL"

# Send
aws sqs send-message --region "$REGION" \
  --queue-url "$QUEUE_URL" \
  --message-body "Hello from $QUEUE_NAME at $(date)" >/dev/null
echo ">> Message sent"

# Receive
echo ">> Polling..."
RESP=$(aws sqs receive-message --region "$REGION" --output json \
  --queue-url "$QUEUE_URL" --max-number-of-messages 1 --wait-time-seconds 5)
echo "$RESP"

HANDLE=$(echo "$RESP" | jq -r '.Messages[0].ReceiptHandle // empty' 2>/dev/null || true)
if [ -n "$HANDLE" ]; then
  aws sqs delete-message --region "$REGION" --queue-url "$QUEUE_URL" --receipt-handle "$HANDLE"
  echo ">> Message deleted"
fi

cat <<EOF

Cleanup:
  aws sqs delete-queue --queue-url $QUEUE_URL
EOF
