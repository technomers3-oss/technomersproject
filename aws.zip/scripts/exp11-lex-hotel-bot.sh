#!/usr/bin/env bash
# Exp-11: Amazon Lex V2 Hotel Booking bot
# Run inside AWS CloudShell (or any shell with aws + jq)
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
SUFFIX="$(date +%s | tail -c 6)"
BOT_NAME="HotelBookingBot-${SUFFIX}"
ROLE_NAME="LexV2HotelBotRole-${SUFFIX}"
LOCALE_ID="en_US"
INTENT_NAME="BookHotel"
SLOT_TYPE_NAME="RoomType"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"

echo ">> Region   : $REGION"
echo ">> BotName  : $BOT_NAME"
echo ">> RoleName : $ROLE_NAME"

# 1. IAM role for Lex
TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lexv2.amazonaws.com"},"Action":"sts:AssumeRole"}]}'

ROLE_ARN=$(aws iam create-role \
  --role-name "$ROLE_NAME" \
  --assume-role-policy-document "$TRUST" \
  --description "Lex V2 runtime role for $BOT_NAME" \
  --query 'Role.Arn' --output text)

aws iam attach-role-policy \
  --role-name "$ROLE_NAME" \
  --policy-arn arn:aws:iam::aws:policy/AmazonLexFullAccess >/dev/null

echo ">> Waiting for IAM role to propagate..."
sleep 12

# 2. Bot
BOT_ID=$(aws lexv2-models create-bot --region "$REGION" \
  --bot-name "$BOT_NAME" \
  --role-arn "$ROLE_ARN" \
  --data-privacy '{"childDirected":false}' \
  --idle-session-ttl-in-seconds 300 \
  --query 'botId' --output text)
echo ">> Bot created: $BOT_ID"

until [ "$(aws lexv2-models describe-bot --region "$REGION" --bot-id "$BOT_ID" --query botStatus --output text)" = "Available" ]; do
  sleep 3
done

# 3. Locale
aws lexv2-models create-bot-locale --region "$REGION" \
  --bot-id "$BOT_ID" --bot-version "DRAFT" \
  --locale-id "$LOCALE_ID" \
  --nlu-intent-confidence-threshold 0.4 >/dev/null

until [ "$(aws lexv2-models describe-bot-locale --region "$REGION" --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" --query botLocaleStatus --output text)" = "NotBuilt" ]; do
  sleep 3
done
echo ">> Locale $LOCALE_ID created"

# 4. Custom slot type RoomType
SLOT_TYPE_ID=$(aws lexv2-models create-slot-type --region "$REGION" \
  --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" \
  --slot-type-name "$SLOT_TYPE_NAME" \
  --value-selection-setting '{"resolutionStrategy":"OriginalValue"}' \
  --slot-type-values '[
    {"sampleValue":{"value":"single"}},
    {"sampleValue":{"value":"double"}},
    {"sampleValue":{"value":"suite"}}
  ]' \
  --query 'slotTypeId' --output text)
echo ">> Slot type RoomType: $SLOT_TYPE_ID"

# 5. Intent
INTENT_ID=$(aws lexv2-models create-intent --region "$REGION" \
  --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" \
  --intent-name "$INTENT_NAME" \
  --sample-utterances '[
    {"utterance":"I want to book a hotel"},
    {"utterance":"Book a room"},
    {"utterance":"Reserve hotel"},
    {"utterance":"I need a room"}
  ]' \
  --query 'intentId' --output text)
echo ">> Intent $INTENT_NAME: $INTENT_ID"

# Helper for plain slots
make_slot () {
  local NAME="$1" TYPE_ID="$2" PROMPT="$3"
  aws lexv2-models create-slot --region "$REGION" \
    --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" \
    --intent-id "$INTENT_ID" \
    --slot-name "$NAME" \
    --slot-type-id "$TYPE_ID" \
    --value-elicitation-setting "$(jq -n --arg p "$PROMPT" '{
      slotConstraint:"Required",
      promptSpecification:{
        messageGroups:[{message:{plainTextMessage:{value:$p}}}],
        maxRetries:2, allowInterrupt:true
      }
    }')" \
    --query 'slotId' --output text
}

AGE_ID=$(make_slot   age    "AMAZON.Number" "What is your age?")
CITY_ID=$(make_slot  city   "AMAZON.City"   "Which city would you like to book in?")
DATE_ID=$(make_slot  date   "AMAZON.Date"   "What date would you like to check in?")
NIGHT_ID=$(make_slot nights "AMAZON.Number" "How many nights will you stay?")

# RoomType slot with button card
ROOM_ID=$(aws lexv2-models create-slot --region "$REGION" \
  --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" \
  --intent-id "$INTENT_ID" \
  --slot-name "RoomType" \
  --slot-type-id "$SLOT_TYPE_ID" \
  --value-elicitation-setting '{
    "slotConstraint":"Required",
    "promptSpecification":{
      "messageGroups":[{
        "message":{
          "imageResponseCard":{
            "title":"Choose room type",
            "buttons":[
              {"text":"single","value":"single"},
              {"text":"double","value":"double"},
              {"text":"suite","value":"suite"}
            ]
          }
        }
      }],
      "maxRetries":2,"allowInterrupt":true
    }
  }' --query 'slotId' --output text)
echo ">> Slots created (age,city,date,nights,RoomType)"

# 6. Update intent with priorities + initial response + confirmation
aws lexv2-models update-intent --region "$REGION" \
  --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" \
  --intent-id "$INTENT_ID" --intent-name "$INTENT_NAME" \
  --sample-utterances '[
    {"utterance":"I want to book a hotel"},
    {"utterance":"Book a room"},
    {"utterance":"Reserve hotel"},
    {"utterance":"I need a room"}
  ]' \
  --slot-priorities "$(jq -n \
      --arg a "$AGE_ID" --arg c "$CITY_ID" --arg d "$DATE_ID" \
      --arg n "$NIGHT_ID" --arg r "$ROOM_ID" \
      '[{priority:1,slotId:$a},{priority:2,slotId:$c},
        {priority:3,slotId:$d},{priority:4,slotId:$n},
        {priority:5,slotId:$r}]')" \
  --initial-response-setting '{
    "initialResponse":{
      "messageGroups":[{"message":{"plainTextMessage":{
        "value":"Welcome to Hotel Booking! What is your name?"}}}],
      "allowInterrupt":true
    }
  }' \
  --intent-confirmation-setting '{
    "promptSpecification":{
      "messageGroups":[{"message":{"plainTextMessage":{
        "value":"Do you want to confirm booking in {city} for {nights} nights?"}}}],
      "maxRetries":2,"allowInterrupt":true
    },
    "declinationResponse":{
      "messageGroups":[{"message":{"plainTextMessage":{
        "value":"Okay, booking cancelled."}}}],
      "allowInterrupt":true
    }
  }' >/dev/null
echo ">> Intent updated"

# 7. Build locale
aws lexv2-models build-bot-locale --region "$REGION" \
  --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" >/dev/null
echo ">> Build started..."

while :; do
  ST=$(aws lexv2-models describe-bot-locale --region "$REGION" \
        --bot-id "$BOT_ID" --bot-version DRAFT --locale-id "$LOCALE_ID" \
        --query botLocaleStatus --output text)
  echo "   status=$ST"
  case "$ST" in
    Built)         echo ">> Build complete"; break ;;
    Failed|*Error*) echo ">> Build failed"; exit 1 ;;
    *) sleep 5 ;;
  esac
done

cat <<EOF

------------------------------------------------------------
Bot Name:  $BOT_NAME
Bot ID:    $BOT_ID
Role:      $ROLE_NAME
Region:    $REGION
Test:      Lex V2 console -> $BOT_NAME -> Test
------------------------------------------------------------
Manual step (conditional branch is fiddly via CLI):
  Intent "$INTENT_NAME" -> slot "age" -> Advanced options ->
  Slot capture -> Branch: if {age} < 18 -> respond
  "You are not eligible to book a hotel" and end the conversation.
EOF
