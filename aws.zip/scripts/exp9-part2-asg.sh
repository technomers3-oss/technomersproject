#!/usr/bin/env bash
# Exp-9 Part 2: AMI + Launch Template + Auto Scaling Group attached to Part 1's ALB/TG
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
PROJECT_TAG="exp9"

if [ ! -f /tmp/exp9-state.sh ]; then
  echo "ERROR: /tmp/exp9-state.sh not found. Run exp9-part1-elb.sh first."; exit 1
fi
source /tmp/exp9-state.sh

AMI_NAME="web-server-ami-${SUFFIX}"
LT_NAME="web-lt-${SUFFIX}"
ASG_NAME="web-asg-${SUFFIX}"

echo ">> Reusing from Part 1:"
echo "   ALB     : $ALB_ARN"
echo "   TG      : $TG_ARN"
echo "   Source  : $INSTANCE1"

# 1. Create AMI from instance 1
AMI_ID=$(aws ec2 create-image --region "$REGION" \
  --instance-id "$INSTANCE1" --name "$AMI_NAME" \
  --description "exp9 base AMI" --no-reboot \
  --query 'ImageId' --output text)
aws ec2 create-tags --region "$REGION" --resources "$AMI_ID" \
  --tags Key=Project,Value="$PROJECT_TAG" Key=Name,Value="$AMI_NAME"
echo ">> AMI created: $AMI_ID, waiting for Available..."
aws ec2 wait image-available --region "$REGION" --image-ids "$AMI_ID"
echo ">> AMI Available"

# 2. Launch template
LT_DATA=$(jq -n --arg ami "$AMI_ID" --arg sg "$WEB_SG" '{
  ImageId:$ami,
  InstanceType:"t3.micro",
  SecurityGroupIds:[$sg],
  TagSpecifications:[{
    ResourceType:"instance",
    Tags:[
      {Key:"Project",Value:"exp9"},
      {Key:"Name",Value:"WebServer-ASG"}
    ]
  }]
}')
LT_ID=$(aws ec2 create-launch-template --region "$REGION" \
  --launch-template-name "$LT_NAME" \
  --launch-template-data "$LT_DATA" \
  --query 'LaunchTemplate.LaunchTemplateId' --output text)
aws ec2 create-tags --region "$REGION" --resources "$LT_ID" \
  --tags Key=Project,Value="$PROJECT_TAG"
echo ">> Launch Template: $LT_ID"

# 3. Auto Scaling Group attached to TG
SUBNET_LIST=$(echo "$ALB_SUBNETS" | tr ' ' ',' | sed 's/,$//')
aws autoscaling create-auto-scaling-group --region "$REGION" \
  --auto-scaling-group-name "$ASG_NAME" \
  --launch-template "LaunchTemplateId=$LT_ID,Version=\$Latest" \
  --min-size 1 --max-size 4 --desired-capacity 2 \
  --vpc-zone-identifier "$SUBNET_LIST" \
  --target-group-arns "$TG_ARN" \
  --health-check-type ELB --health-check-grace-period 300 \
  --tags "Key=Project,Value=$PROJECT_TAG,PropagateAtLaunch=true"
echo ">> ASG created: $ASG_NAME"

cat >> /tmp/exp9-state.sh <<EOF
AMI_ID=$AMI_ID
LT_ID=$LT_ID
ASG_NAME=$ASG_NAME
EOF

cat <<EOF

------------------------------------------------------------
ASG launching... ASG instances appear in ~1-2 min, become healthy in ~3-5 min.

Watch ASG fill up:
  aws autoscaling describe-auto-scaling-groups --region $REGION \\
    --auto-scaling-group-names $ASG_NAME \\
    --query 'AutoScalingGroups[0].Instances[].[InstanceId,LifecycleState,HealthStatus]' --output table

Test auto-healing:
  Terminate one instance from EC2 console -> ASG launches a replacement.

Test load balancing:
  http://$DNS  (refresh repeatedly)
------------------------------------------------------------
EOF
