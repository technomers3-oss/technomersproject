#!/usr/bin/env bash
# Exp-8 Part 2: S3 upload -> SNS email
# Usage:  ./exp8-part2-s3-sns.sh <email>
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
EMAIL_RE='^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
EMAIL="${1:-}"
if [[ -z "$EMAIL" ]]; then
  echo "ERROR: email argument is required." >&2
  echo "Usage: $0 <email>" >&2
fi
while [[ ! "$EMAIL" =~ $EMAIL_RE ]]; do
  [[ -n "$EMAIL" ]] && echo "ERROR: '$EMAIL' is not a valid email address." >&2
  read -r -p ">> Enter a valid email to proceed: " EMAIL
done
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
SUFFIX="$(date +%s | tail -c 6)"

TOPIC_NAME="S3UploadAlerts-${SUFFIX}"
BUCKET="s3-sns-demo-${SUFFIX}"

echo ">> Email  : $EMAIL"
echo ">> Topic  : $TOPIC_NAME"
echo ">> Bucket : $BUCKET"

# 1. SNS topic + email subscription
TOPIC_ARN=$(aws sns create-topic --region "$REGION" --name "$TOPIC_NAME" --query 'TopicArn' --output text)
aws sns subscribe --region "$REGION" \
  --topic-arn "$TOPIC_ARN" \
  --protocol email \
  --notification-endpoint "$EMAIL" >/dev/null
echo ">> Subscription created. CONFIRM the link in $EMAIL (also check spam)."
read -r -p ">> Press ENTER after confirming the subscription... "

# 2. Bucket
if [ "$REGION" = "us-east-1" ]; then
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" >/dev/null
else
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
    --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
fi
echo ">> Bucket created"

# 3. SNS access policy allowing S3 to publish
POLICY=$(cat <<EOF
{
  "Version":"2012-10-17","Id":"s3-to-sns","Statement":[{
    "Sid":"AllowS3Publish","Effect":"Allow",
    "Principal":{"Service":"s3.amazonaws.com"},
    "Action":["SNS:Publish"],
    "Resource":"$TOPIC_ARN",
    "Condition":{
      "ArnLike":{"aws:SourceArn":"arn:aws:s3:::$BUCKET"},
      "StringEquals":{"aws:SourceAccount":"$ACCOUNT_ID"}
    }
  }]
}
EOF
)
aws sns set-topic-attributes --region "$REGION" \
  --topic-arn "$TOPIC_ARN" --attribute-name Policy \
  --attribute-value "$POLICY"
echo ">> SNS policy set"

# 4. S3 event notification -> SNS
aws s3api put-bucket-notification-configuration --region "$REGION" \
  --bucket "$BUCKET" \
  --notification-configuration "{
    \"TopicConfigurations\":[{
      \"Id\":\"S3UploadEvent\",
      \"TopicArn\":\"$TOPIC_ARN\",
      \"Events\":[\"s3:ObjectCreated:*\"]
    }]
  }"
echo ">> S3 -> SNS notification wired"

cat <<EOF

Test:
  echo "hello \$(date)" > demo.txt
  aws s3 cp demo.txt s3://$BUCKET/
  # Check $EMAIL inbox.

Resources:
  Bucket : $BUCKET
  Topic  : $TOPIC_ARN
EOF
