#!/usr/bin/env bash
# Exp-8 Part 4: S3 -> SNS -> SQS -> Lambda pipeline
set -euo pipefail

REGION="${AWS_REGION:-us-east-1}"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
SUFFIX="$(date +%s | tail -c 6)"

BUCKET="pipeline-demo-${SUFFIX}"
TOPIC_NAME="PipelineTopic-${SUFFIX}"
QUEUE_NAME="PipelineQueue-${SUFFIX}"
FUNCTION="PipelineProcessor-${SUFFIX}"
ROLE_NAME="PipelineLambdaRole-${SUFFIX}"

echo ">> Bucket   : $BUCKET"
echo ">> Topic    : $TOPIC_NAME"
echo ">> Queue    : $QUEUE_NAME"
echo ">> Function : $FUNCTION"

# 1. SNS, SQS, S3
TOPIC_ARN=$(aws sns create-topic --region "$REGION" --name "$TOPIC_NAME" --query 'TopicArn' --output text)
QUEUE_URL=$(aws sqs create-queue --region "$REGION" --queue-name "$QUEUE_NAME" --query 'QueueUrl' --output text)
QUEUE_ARN=$(aws sqs get-queue-attributes --region "$REGION" --queue-url "$QUEUE_URL" \
  --attribute-names QueueArn --query 'Attributes.QueueArn' --output text)

if [ "$REGION" = "us-east-1" ]; then
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" >/dev/null
else
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
    --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
fi
echo ">> SNS, SQS, S3 created"

# 2. SQS policy allowing SNS to send
SQS_POLICY=$(jq -n --arg q "$QUEUE_ARN" --arg t "$TOPIC_ARN" '{
  Version:"2012-10-17",
  Statement:[{
    Effect:"Allow",
    Principal:{Service:"sns.amazonaws.com"},
    Action:"sqs:SendMessage",
    Resource:$q,
    Condition:{ArnEquals:{"aws:SourceArn":$t}}
  }]
}')
aws sqs set-queue-attributes --region "$REGION" \
  --queue-url "$QUEUE_URL" \
  --attributes "{\"Policy\":$(echo "$SQS_POLICY" | jq -Rs .)}"
echo ">> SQS policy set"

# 3. SNS subscription to SQS
aws sns subscribe --region "$REGION" \
  --topic-arn "$TOPIC_ARN" \
  --protocol sqs \
  --notification-endpoint "$QUEUE_ARN" >/dev/null
echo ">> SNS -> SQS subscribed"

# 4. SNS policy allowing S3 to publish
SNS_POLICY=$(jq -n --arg t "$TOPIC_ARN" --arg b "arn:aws:s3:::$BUCKET" --arg a "$ACCOUNT_ID" '{
  Version:"2012-10-17",Id:"s3-to-sns",
  Statement:[{
    Sid:"AllowS3Publish",Effect:"Allow",
    Principal:{Service:"s3.amazonaws.com"},
    Action:["SNS:Publish"],
    Resource:$t,
    Condition:{
      ArnLike:{"aws:SourceArn":$b},
      StringEquals:{"aws:SourceAccount":$a}
    }
  }]
}')
aws sns set-topic-attributes --region "$REGION" \
  --topic-arn "$TOPIC_ARN" --attribute-name Policy \
  --attribute-value "$SNS_POLICY"
echo ">> SNS policy set"

# 5. S3 -> SNS event notification
aws s3api put-bucket-notification-configuration --region "$REGION" \
  --bucket "$BUCKET" \
  --notification-configuration "{
    \"TopicConfigurations\":[{
      \"Id\":\"S3UploadEvent\",
      \"TopicArn\":\"$TOPIC_ARN\",
      \"Events\":[\"s3:ObjectCreated:*\"]
    }]
  }"
echo ">> S3 -> SNS notification wired"

# 6. Lambda role
TRUST='{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"lambda.amazonaws.com"},"Action":"sts:AssumeRole"}]}'
ROLE_ARN=$(aws iam create-role --role-name "$ROLE_NAME" \
  --assume-role-policy-document "$TRUST" --query 'Role.Arn' --output text)
aws iam attach-role-policy --role-name "$ROLE_NAME" \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole >/dev/null
aws iam attach-role-policy --role-name "$ROLE_NAME" \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaSQSQueueExecutionRole >/dev/null
echo ">> IAM role created, waiting for propagation..."
sleep 12

# 7. Lambda function
WORK="$(mktemp -d)"
cat > "$WORK/lambda_function.py" <<'PY'
def lambda_handler(event, context):
    for record in event['Records']:
        print("Message received from SQS:")
        print(record['body'])
    return {'statusCode': 200, 'body': 'Message processed successfully'}
PY
(cd "$WORK" && zip -q function.zip lambda_function.py)

for i in 1 2 3 4 5; do
  if aws lambda create-function --region "$REGION" \
      --function-name "$FUNCTION" \
      --runtime python3.12 \
      --role "$ROLE_ARN" \
      --handler lambda_function.lambda_handler \
      --zip-file "fileb://$WORK/function.zip" \
      --timeout 30 >/dev/null 2>&1; then
    echo ">> Lambda created (attempt $i)"
    break
  fi
  echo "   role not ready, retrying..."; sleep 6
done
aws lambda wait function-active-v2 --region "$REGION" --function-name "$FUNCTION"
echo ">> Lambda ACTIVE"

# 8. SQS -> Lambda event source mapping
aws lambda create-event-source-mapping --region "$REGION" \
  --function-name "$FUNCTION" \
  --event-source-arn "$QUEUE_ARN" \
  --batch-size 5 >/dev/null
echo ">> SQS -> Lambda trigger wired"

cat <<EOF

------------------------------------------------------------
Test the pipeline:
  echo "hello \$(date)" > demo.txt
  aws s3 cp demo.txt s3://$BUCKET/
  aws logs tail /aws/lambda/$FUNCTION --region $REGION --follow

Flow: S3 upload -> SNS topic -> SQS queue -> Lambda -> CloudWatch logs

Resources:
  Bucket : $BUCKET
  Topic  : $TOPIC_ARN
  Queue  : $QUEUE_URL
  Lambda : $FUNCTION
  Role   : $ROLE_NAME
------------------------------------------------------------
EOF
