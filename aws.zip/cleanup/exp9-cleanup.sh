#!/usr/bin/env bash
# Exp-9 cleanup — wipes everything tagged Project=exp9
set -uo pipefail

REGION="${AWS_REGION:-us-east-1}"
TAG="exp9"

# 1. Delete ASGs (must go first — they hold instances + LT)
echo "=== Auto Scaling Groups ==="
for ASG in $(aws autoscaling describe-auto-scaling-groups --region "$REGION" \
    --query "AutoScalingGroups[?starts_with(AutoScalingGroupName,\`web-asg-\`)].AutoScalingGroupName" --output text); do
  echo ">> deleting ASG $ASG"
  aws autoscaling update-auto-scaling-group --region "$REGION" \
    --auto-scaling-group-name "$ASG" --min-size 0 --desired-capacity 0 >/dev/null
  aws autoscaling delete-auto-scaling-group --region "$REGION" \
    --auto-scaling-group-name "$ASG" --force-delete
done

# Wait for ASG-launched instances to terminate
echo ">> waiting 30s for ASG instances to terminate..."
sleep 30

# 2. Listeners + Load Balancers
echo
echo "=== Load Balancers ==="
for ALB in $(aws elbv2 describe-load-balancers --region "$REGION" \
    --query "LoadBalancers[?starts_with(LoadBalancerName,\`web-alb-\`)].LoadBalancerArn" --output text); do
  echo ">> deleting ALB $ALB"
  aws elbv2 delete-load-balancer --region "$REGION" --load-balancer-arn "$ALB"
done

echo ">> waiting 25s for ALB deletion..."
sleep 25

# 3. Target groups
echo
echo "=== Target Groups ==="
for TG in $(aws elbv2 describe-target-groups --region "$REGION" \
    --query "TargetGroups[?starts_with(TargetGroupName,\`web-tg-\`)].TargetGroupArn" --output text); do
  echo ">> deleting TG $TG"
  aws elbv2 delete-target-group --region "$REGION" --target-group-arn "$TG"
done

# 4. EC2 instances tagged Project=exp9
echo
echo "=== EC2 Instances ==="
INSTANCES=$(aws ec2 describe-instances --region "$REGION" \
  --filters "Name=tag:Project,Values=$TAG" "Name=instance-state-name,Values=pending,running,stopping,stopped" \
  --query 'Reservations[].Instances[].InstanceId' --output text)
if [ -n "$INSTANCES" ]; then
  echo ">> terminating $INSTANCES"
  aws ec2 terminate-instances --region "$REGION" --instance-ids $INSTANCES >/dev/null
  aws ec2 wait instance-terminated --region "$REGION" --instance-ids $INSTANCES
fi

# 5. Launch templates
echo
echo "=== Launch Templates ==="
for LT in $(aws ec2 describe-launch-templates --region "$REGION" \
    --query "LaunchTemplates[?starts_with(LaunchTemplateName,\`web-lt-\`)].LaunchTemplateId" --output text 2>/dev/null); do
  echo ">> deleting LT $LT"
  aws ec2 delete-launch-template --region "$REGION" --launch-template-id "$LT" >/dev/null
done

# 6. AMIs (deregister) + their snapshots
echo
echo "=== AMIs + Snapshots ==="
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
for AMI in $(aws ec2 describe-images --region "$REGION" --owners "$ACCOUNT_ID" \
    --filters "Name=name,Values=web-server-ami-*" \
    --query 'Images[].ImageId' --output text); do
  SNAPS=$(aws ec2 describe-images --region "$REGION" --image-ids "$AMI" \
    --query 'Images[0].BlockDeviceMappings[].Ebs.SnapshotId' --output text)
  echo ">> deregistering $AMI"
  aws ec2 deregister-image --region "$REGION" --image-id "$AMI"
  for S in $SNAPS; do
    [ -n "$S" ] && [ "$S" != "None" ] && aws ec2 delete-snapshot --region "$REGION" --snapshot-id "$S" 2>/dev/null || true
  done
done

# 7. Security groups (after instances + ALB are gone)
echo
echo "=== Security Groups ==="
for SG in $(aws ec2 describe-security-groups --region "$REGION" \
    --filters "Name=tag:Project,Values=$TAG" \
    --query 'SecurityGroups[].GroupId' --output text); do
  echo ">> deleting SG $SG"
  for try in 1 2 3 4; do
    if aws ec2 delete-security-group --region "$REGION" --group-id "$SG" 2>/dev/null; then
      break
    fi
    echo "   still in use, retrying in 10s..."; sleep 10
  done
done

rm -f /tmp/exp9-state.sh

echo
echo ">> done"
