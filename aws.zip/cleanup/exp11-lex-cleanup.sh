#!/usr/bin/env bash
# Exp-11 cleanup — deletes all Lex bots + roles created by exp11-lex-hotel-bot.sh
set -uo pipefail

REGION="${AWS_REGION:-us-east-1}"

echo "=== Lex V2 bots (HotelBookingBot-*) ==="
for ID in $(aws lexv2-models list-bots --region "$REGION" \
    --query 'botSummaries[?starts_with(botName,`HotelBookingBot-`)].botId' --output text); do
  NAME=$(aws lexv2-models describe-bot --region "$REGION" --bot-id "$ID" --query botName --output text)
  echo ">> deleting bot $NAME ($ID)"
  aws lexv2-models delete-bot --region "$REGION" --bot-id "$ID" --skip-resource-in-use-check >/dev/null
done

echo
echo "=== IAM roles (LexV2HotelBotRole-*) ==="
for ROLE in $(aws iam list-roles \
    --query 'Roles[?starts_with(RoleName,`LexV2HotelBotRole-`)].RoleName' --output text); do
  echo ">> cleaning role $ROLE"
  for P in $(aws iam list-attached-role-policies --role-name "$ROLE" \
        --query 'AttachedPolicies[].PolicyArn' --output text); do
    aws iam detach-role-policy --role-name "$ROLE" --policy-arn "$P"
  done
  for P in $(aws iam list-role-policies --role-name "$ROLE" \
        --query 'PolicyNames' --output text); do
    aws iam delete-role-policy --role-name "$ROLE" --policy-name "$P"
  done
  aws iam delete-role --role-name "$ROLE"
done

echo
echo "=== Verify ==="
aws lexv2-models list-bots --region "$REGION" \
  --query 'botSummaries[?starts_with(botName,`HotelBookingBot-`)].botName' --output text
aws iam list-roles --query 'Roles[?starts_with(RoleName,`LexV2HotelBotRole-`)].RoleName' --output text
echo ">> done"
