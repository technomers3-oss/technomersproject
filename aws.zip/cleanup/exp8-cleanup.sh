#!/usr/bin/env bash
# Exp-8 cleanup — wipes everything from any of the four exp8 parts
set -uo pipefail

REGION="${AWS_REGION:-us-east-1}"

# --- Lambdas (PipelineProcessor-*) ---
echo "=== Lambda functions ==="
for FN in $(aws lambda list-functions --region "$REGION" \
    --query 'Functions[?starts_with(FunctionName,`PipelineProcessor-`)].FunctionName' --output text); do
  echo ">> deleting Lambda $FN"
  for ESM in $(aws lambda list-event-source-mappings --region "$REGION" \
        --function-name "$FN" --query 'EventSourceMappings[].UUID' --output text); do
    aws lambda delete-event-source-mapping --region "$REGION" --uuid "$ESM" >/dev/null || true
  done
  aws lambda delete-function --region "$REGION" --function-name "$FN"
  aws logs delete-log-group --region "$REGION" --log-group-name "/aws/lambda/$FN" 2>/dev/null || true
done

# --- S3 buckets ---
echo
echo "=== S3 buckets ==="
for B in $(aws s3api list-buckets \
    --query 'Buckets[?starts_with(Name,`s3-sns-demo-`) || starts_with(Name,`pipeline-demo-`)].Name' --output text); do
  echo ">> emptying + deleting bucket $B"
  aws s3 rm "s3://$B" --recursive 2>/dev/null || true
  aws s3api delete-bucket --bucket "$B" --region "$REGION"
done

# --- SQS queues ---
echo
echo "=== SQS queues ==="
for URL in $(aws sqs list-queues --region "$REGION" --query 'QueueUrls' --output text 2>/dev/null); do
  case "$URL" in
    *DemoQueue-*|*PipelineQueue-*)
      echo ">> deleting queue $URL"
      aws sqs delete-queue --region "$REGION" --queue-url "$URL"
      ;;
  esac
done

# --- SNS topics ---
echo
echo "=== SNS topics ==="
for ARN in $(aws sns list-topics --region "$REGION" --query 'Topics[].TopicArn' --output text); do
  case "$ARN" in
    *:DemoNotifications-*|*:S3UploadAlerts-*|*:PipelineTopic-*)
      echo ">> deleting topic $ARN"
      aws sns delete-topic --region "$REGION" --topic-arn "$ARN"
      ;;
  esac
done

# --- IAM roles (PipelineLambdaRole-*) ---
echo
echo "=== IAM roles ==="
for ROLE in $(aws iam list-roles \
    --query 'Roles[?starts_with(RoleName,`PipelineLambdaRole-`)].RoleName' --output text); do
  echo ">> cleaning role $ROLE"
  for P in $(aws iam list-attached-role-policies --role-name "$ROLE" \
        --query 'AttachedPolicies[].PolicyArn' --output text); do
    aws iam detach-role-policy --role-name "$ROLE" --policy-arn "$P"
  done
  for P in $(aws iam list-role-policies --role-name "$ROLE" \
        --query 'PolicyNames' --output text); do
    aws iam delete-role-policy --role-name "$ROLE" --policy-name "$P"
  done
  aws iam delete-role --role-name "$ROLE"
done

echo
echo ">> done"
