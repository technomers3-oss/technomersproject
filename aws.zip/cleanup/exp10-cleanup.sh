#!/usr/bin/env bash
# Exp-10 cleanup — wipes Elastic Beanstalk app, env, S3 source bucket, IAM roles
set -uo pipefail

REGION="${AWS_REGION:-us-east-1}"

# 1. Terminate environments (TomcatDemoEnv-*)
echo "=== EB environments ==="
for ENV in $(aws elasticbeanstalk describe-environments --region "$REGION" \
    --query "Environments[?starts_with(EnvironmentName,\`TomcatDemoEnv-\`) && Status!=\`Terminated\`].EnvironmentName" --output text); do
  echo ">> terminating $ENV"
  aws elasticbeanstalk terminate-environment --region "$REGION" \
    --environment-name "$ENV" >/dev/null
done

# Wait until terminated
echo ">> waiting for environments to terminate (may take 3-5 min)..."
while :; do
  ACTIVE=$(aws elasticbeanstalk describe-environments --region "$REGION" \
    --query "Environments[?starts_with(EnvironmentName,\`TomcatDemoEnv-\`) && Status!=\`Terminated\`].EnvironmentName" --output text)
  [ -z "$ACTIVE" ] && break
  echo "   still: $ACTIVE"
  sleep 20
done

# 2. Delete applications
echo
echo "=== EB applications ==="
for APP in $(aws elasticbeanstalk describe-applications --region "$REGION" \
    --query "Applications[?starts_with(ApplicationName,\`TomcatDemoApp-\`)].ApplicationName" --output text); do
  echo ">> deleting application $APP"
  aws elasticbeanstalk delete-application --region "$REGION" \
    --application-name "$APP" --terminate-env-by-force 2>/dev/null || true
done

# 3. Source S3 buckets
echo
echo "=== S3 buckets ==="
for B in $(aws s3api list-buckets \
    --query 'Buckets[?starts_with(Name,`eb-tomcat-source-`)].Name' --output text); do
  echo ">> emptying + deleting $B"
  aws s3 rm "s3://$B" --recursive 2>/dev/null || true
  aws s3api delete-bucket --bucket "$B" --region "$REGION" 2>/dev/null || true
done

# 4. EB-created storage buckets (elasticbeanstalk-<region>-<account>) — leave these, AWS reuses them

# 5. Instance profiles
echo
echo "=== Instance profiles ==="
for IP in $(aws iam list-instance-profiles \
    --query 'InstanceProfiles[?starts_with(InstanceProfileName,`EBInstanceProfile-`)].InstanceProfileName' --output text); do
  echo ">> cleaning instance profile $IP"
  for R in $(aws iam get-instance-profile --instance-profile-name "$IP" \
        --query 'InstanceProfile.Roles[].RoleName' --output text); do
    aws iam remove-role-from-instance-profile --instance-profile-name "$IP" --role-name "$R"
  done
  aws iam delete-instance-profile --instance-profile-name "$IP"
done

# 6. IAM roles
echo
echo "=== IAM roles ==="
for ROLE in $(aws iam list-roles \
    --query 'Roles[?starts_with(RoleName,`EBServiceRole-`) || starts_with(RoleName,`EBInstanceRole-`)].RoleName' --output text); do
  echo ">> cleaning $ROLE"
  for P in $(aws iam list-attached-role-policies --role-name "$ROLE" \
        --query 'AttachedPolicies[].PolicyArn' --output text); do
    aws iam detach-role-policy --role-name "$ROLE" --policy-arn "$P"
  done
  for P in $(aws iam list-role-policies --role-name "$ROLE" \
        --query 'PolicyNames' --output text); do
    aws iam delete-role-policy --role-name "$ROLE" --policy-name "$P"
  done
  aws iam delete-role --role-name "$ROLE"
done

rm -f /tmp/exp10-state.sh
echo
echo ">> done"
