#!/usr/bin/env bash
# Exp-7 cleanup — removes ALL resources from exp7-s3-dynamodb.sh runs
set -uo pipefail

REGION="${AWS_REGION:-us-east-1}"

echo "=== Lambda functions (S3ToDynamoLogger-*) ==="
for FN in $(aws lambda list-functions --region "$REGION" \
    --query 'Functions[?starts_with(FunctionName,`S3ToDynamoLogger-`)].FunctionName' --output text); do
  echo ">> deleting Lambda $FN"
  aws lambda delete-function --region "$REGION" --function-name "$FN"
  aws logs delete-log-group --region "$REGION" --log-group-name "/aws/lambda/$FN" 2>/dev/null || true
done

echo
echo "=== S3 buckets (s3-to-dynamo-demo-*) ==="
for B in $(aws s3api list-buckets \
    --query 'Buckets[?starts_with(Name,`s3-to-dynamo-demo-`)].Name' --output text); do
  echo ">> emptying + deleting bucket $B"
  aws s3 rm "s3://$B" --recursive 2>/dev/null || true
  aws s3api delete-bucket --bucket "$B" --region "$REGION"
done

echo
echo "=== DynamoDB tables (S3UploadLogs-*) ==="
for T in $(aws dynamodb list-tables --region "$REGION" --query 'TableNames' --output text); do
  case "$T" in
    S3UploadLogs-*|S3UploadLogs)
      echo ">> deleting table $T"
      aws dynamodb delete-table --region "$REGION" --table-name "$T" >/dev/null
      ;;
  esac
done

echo
echo "=== IAM roles (S3ToDynamoLambdaRole-*) ==="
for ROLE in $(aws iam list-roles \
    --query 'Roles[?starts_with(RoleName,`S3ToDynamoLambdaRole-`)].RoleName' --output text); do
  echo ">> cleaning role $ROLE"
  for P in $(aws iam list-attached-role-policies --role-name "$ROLE" \
        --query 'AttachedPolicies[].PolicyArn' --output text); do
    aws iam detach-role-policy --role-name "$ROLE" --policy-arn "$P"
  done
  for P in $(aws iam list-role-policies --role-name "$ROLE" \
        --query 'PolicyNames' --output text); do
    aws iam delete-role-policy --role-name "$ROLE" --policy-name "$P"
  done
  aws iam delete-role --role-name "$ROLE"
done

echo
echo "=== Verify ==="
aws lambda list-functions --region "$REGION" --query 'Functions[?starts_with(FunctionName,`S3ToDynamoLogger-`)].FunctionName' --output text
aws s3api list-buckets --query 'Buckets[?starts_with(Name,`s3-to-dynamo-demo-`)].Name' --output text
aws dynamodb list-tables --region "$REGION" --query 'TableNames' --output text | tr '\t' '\n' | grep '^S3UploadLogs' || true
aws iam list-roles --query 'Roles[?starts_with(RoleName,`S3ToDynamoLambdaRole-`)].RoleName' --output text
echo ">> done"
